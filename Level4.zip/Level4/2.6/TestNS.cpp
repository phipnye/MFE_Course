// TestNS.cpp
//
// Program that will not compile. Solve by 3 uses of 
// C++ namespaces.
//
// DJD
//

#include <iostream>

int main()
{
	cout << "why will it not compile?? " << endl;

	return 0;
}
