// Hello.hpp
//
// Simple example of function declarations.
//

// Preprocessor directive

#ifndef Hello_HPP
#define Hello_HPP

void hello_C(); // No return value, no input argument
void hello_CPP();

#endif